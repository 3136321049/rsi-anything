"""Run state on disk: an append-only ledger per run and lessons that outlive runs.

Layout inside the project (excluded from git automatically):

    .rsi/
      lessons/<contract-name>.md      lessons carried into every future run
      runs/<run-id>/run.json          what was frozen, base commit, branch, agent
      runs/<run-id>/ledger.jsonl      one row per round, never rewritten
      runs/<run-id>/rounds/rNNN/      prompt, agent transcript, judge output, diff
      worktrees/<run-id>/             the agent's sandbox checkout
"""
from __future__ import annotations

import json
import os
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any, Optional

from .artifacts import write_json
# 轮次状态与账本行属于领域层，这里保留旧的导入位置。
from .domain import (AGENT_FAIL, BASELINE, INTERRUPTED, JUDGE_FAIL, KEEP, NO_CHANGE, REVERT,  # noqa: F401
                     Row, now)

STATE_DIR = ".rsi"
# 运行记录格式版本：run.json 带 `schema`；没有该字段的旧记录按 1 读取。
SCHEMA_VERSION = 1


def new_run_id(name: str, repo: Optional[Path] = None) -> str:
    slug = "".join(c if c.isalnum() else "-" for c in name.lower()).strip("-")[:32] or "run"
    run_id = f"{time.strftime('%Y%m%d-%H%M%S')}-{slug}"
    if repo is not None:  # two runs started within the same second must not share a folder
        runs, base, n = Path(repo) / STATE_DIR / "runs", run_id, 1
        while (runs / run_id).exists():
            n += 1
            run_id = f"{base}-{n}"
    return run_id


class RunStore:
    def __init__(self, repo: Path, run_id: str):
        self.repo = Path(repo)
        self.run_id = run_id
        self.dir = self.repo / STATE_DIR / "runs" / run_id
        self.dir.mkdir(parents=True, exist_ok=True)

    @property
    def worktree(self) -> Path:
        return self.repo / STATE_DIR / "worktrees" / self.run_id

    @property
    def ledger_path(self) -> Path:
        return self.dir / "ledger.jsonl"

    def round_dir(self, number: int) -> Path:
        path = self.dir / "rounds" / f"r{number:03d}"
        path.mkdir(parents=True, exist_ok=True)
        return path

    def write_meta(self, meta: dict[str, Any]):
        write_json(self.dir / "run.json", meta)

    def meta(self) -> dict[str, Any]:
        path = self.dir / "run.json"
        return json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}

    def append(self, row: Row):
        if any(item["round"] == row.round for item in self.rows()):
            raise ValueError(f"round {row.round} is already recorded")
        # 保留异常退出留下的尾部片段，再补写完整记录。
        if self.ledger_path.exists():
            content = self.ledger_path.read_bytes()
            if content and not content.endswith(b"\n"):
                tail = content.rsplit(b"\n", 1)[-1]
                try:
                    json.loads(tail)
                except (ValueError, UnicodeDecodeError):
                    (self.dir / "ledger.interrupted-tail").write_bytes(tail)
                    self.ledger_path.write_bytes(content[:-len(tail)])
                else:
                    with self.ledger_path.open("ab") as stream:
                        stream.write(b"\n")
        with self.ledger_path.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(asdict(row), ensure_ascii=False) + "\n")
            stream.flush()
            os.fsync(stream.fileno())

    def complete_round(self, row: Row):
        write_json(self.round_dir(row.round) / "result.json", asdict(row))
        self.append(row)

    def recover_rounds(self):
        """补齐已落盘、但还没追加到账本的完整轮次。"""
        recorded = {item["round"] for item in self.rows()}
        for path in sorted((self.dir / "rounds").glob("r*/result.json")):
            row = Row(**json.loads(path.read_text(encoding="utf-8")))
            if row.round not in recorded:
                self.append(row)
                recorded.add(row.round)

    def rows(self) -> list[dict[str, Any]]:
        if not self.ledger_path.exists():
            return []
        content = self.ledger_path.read_bytes()
        rows = []
        lines = content.splitlines()
        for index, line in enumerate(lines):
            if not line.strip():
                continue
            try:
                rows.append(json.loads(line))
            except (ValueError, UnicodeDecodeError):
                if index == len(lines) - 1 and not content.endswith(b"\n"):
                    break
                raise
        return rows


def lessons_path(repo: Path, contract_name: str) -> Path:
    slug = "".join(c if c.isalnum() or c in "-_" else "-" for c in contract_name) or "default"
    return Path(repo) / STATE_DIR / "lessons" / f"{slug}.md"


def read_lessons(repo: Path, contract_name: str, limit: int = 12) -> list[str]:
    path = lessons_path(repo, contract_name)
    if not path.exists():
        return []
    lines = [line[2:] for line in path.read_text(encoding="utf-8").splitlines() if line.startswith("- ")]
    return lines[-limit:]


def add_lesson(repo: Path, contract_name: str, text: str):
    path = lessons_path(repo, contract_name)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        path.write_text(f"# Lessons for {contract_name}\n\n", encoding="utf-8")
    clean = " ".join(text.split())
    with path.open("a", encoding="utf-8") as stream:
        stream.write(f"- {clean}\n")


def list_runs(repo: Path) -> list[str]:
    runs = Path(repo) / STATE_DIR / "runs"
    return sorted(p.name for p in runs.iterdir() if p.is_dir()) if runs.exists() else []
